import keyboard
import time

import numpy as np

import matplotlib.pyplot as plt

# Variável para armazenar o tempo da última tecla pressionada
last_time = None

durations = np.array([])

measures = np.array((10-2)*[4])
measures = np.append(measures, 1*[9])
measures = np.append(measures, 1*[2])
measures = np.append(measures, 74*[4])
measures = np.append(measures, 14*[9])
measures = np.append(measures, 64*[4])
measures = np.append(measures, 3*[3])
measures = np.append(measures, 33*[4])
measures = np.append(measures, 8*[4])
measures = np.append(measures, 45*[4])
measures = np.append(measures, 2*[6])
measures = np.append(measures, 44*[4])
measures = np.append(measures, 1*[7])
measures = np.append(measures, 13*[4])
measures = np.append(measures, 15*[12])
measures = np.append(measures, 1*[3])
measures = np.append(measures, 187*[4])
measures = np.append(measures, 4*[3])
measures = np.append(measures, 31*[4])
measures = np.append(measures, 1*[5])
measures = np.append(measures, 2*[4])
measures = np.append(measures, 1*[5])
measures = np.append(measures, 77*[4])
measures = np.append(measures, 2*[3])
measures = np.append(measures, 1*[4])


# 2 compassos pra pegar andamento
referencia = np.array((10-2)*[105])
referencia = np.append(referencia, 1*[210])
referencia = np.append(referencia, 75*[140])
referencia = np.append(referencia, 14*[280])
referencia = np.append(referencia, 67*[140])
referencia = np.append(referencia, 33*[187])
referencia = np.append(referencia, 8*[93])
referencia = np.append(referencia, 90*[140])
referencia = np.append(referencia, 13*[93])
referencia = np.append(referencia, 15*[189])
referencia = np.append(referencia, 72*[140])
referencia = np.append(referencia, 15*[93])
referencia = np.append(referencia, 47*[187])
referencia = np.append(referencia, 173*[140])


mudancas = np.array([["Ijexa - 4/4 - 105", 0, 4, 105]])
mudancas = np.append(mudancas, [["Transiçao Ijexa - 6/8 - 210", 8, 6, 210]], axis=0)
mudancas = np.append(mudancas, [["Barravento - 6/8 - 210", 9, 6, 210]], axis=0)
mudancas = np.append(mudancas, [["Retomada barravento - 4/4 - 140", 14, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Samba - 4/4 - 140", 24, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["XL - 4/4 - 140", 32, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Salmonela - 4/4 - 140", 63, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Treansicion - 4/4 - 140", 82, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Noveoito - 9/8 - 280", 86, 9, 280]], axis=0)
mudancas = np.append(mudancas, [["Retomada - 4/4 - 140", 100, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Aquarela Chamada - 4/4 - 140", 112, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Aquarela Solo - 4/4 - 140", 138, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Bhangra desengatada - 3/4 - 140", 164, 3, 140]], axis=0)
mudancas = np.append(mudancas, [["Bhangra makonha - 4/4 - 187", 167, 4, 187]], axis=0)
mudancas = np.append(mudancas, [["Bhangra Solo - 4/4 - 187", 185, 4, 187]], axis=0)
mudancas = np.append(mudancas, [["UUUMMM DOIS - 4/4 - 187", 205, 4, 187]], axis=0)
mudancas = np.append(mudancas, [["Samba - 4/4 - 140", 218, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Tois - 4/4 - 140", 224, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Samba em 6 - 6/4 - 140", 261, 6, 140]], axis=0)
mudancas = np.append(mudancas, [["Brastemp - 4/4 - 140", 263, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Jongo - 4/4 - 140", 283, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Pare - 4/4 - 140", 298, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Flamenco Intro - 7/4 - 140", 305, 7, 140]], axis=0)
mudancas = np.append(mudancas, [["Flamenco REAL - 4/4 - 93", 306, 4, 93]], axis=0)
mudancas = np.append(mudancas, [["Flamenco CERNE - 12/8 - 93", 317, 12, 93]], axis=0)
mudancas = np.append(mudancas, [["Flamenco FINAL - 3/4 - 140", 339, 3, 140]], axis=0)
mudancas = np.append(mudancas, [["Samba - 4/4 - 140", 335, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["N sei - 4/4 - 140", 349, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Solo pinico - 4/4 - 140", 363, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Makulele - 4/4 - 140", 390, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Whiskas - 4/4 - 140", 402, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Whiskas LENTO - 4/4 - 93", 406, 4, 93]], axis=0)
mudancas = np.append(mudancas, [["SOLO DE SEXO - 4/4 - 196", 421, 4, 196]], axis=0)
mudancas = np.append(mudancas, [["BLACK HAHAHA - 4/4 - 196", 435, 4, 196]], axis=0)
mudancas = np.append(mudancas, [["Frevo - 4/4 - 196", 451, 4, 196]], axis=0)
mudancas = np.append(mudancas, [["Saksifufu - 4/4 - 140", 468, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Hunter - 4/4 - 140", 485, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Bilu intro - 3/4 - 140", 523, 3, 140]], axis=0)
mudancas = np.append(mudancas, [["Bilu - 4/4 - 140", 527, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Makumba - 5/4 - 140", 556, 5, 140]], axis=0)
mudancas = np.append(mudancas, [["Makumba - 4/4 - 140", 557, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Makumba - 5/4 - 140", 559, 5, 140]], axis=0)
mudancas = np.append(mudancas, [["Makumba - 4/4 - 140", 560, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Timpanos - 4/4 - 140", 570, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Caveça - 4/4 - 140", 586, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Dinossauro - 4/4 - 140", 622, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Pre final - 3/4 - 140", 639, 3, 140]], axis=0)
mudancas = np.append(mudancas, [["CABO - 4/4 - 140", 641, 4, 140]], axis=0)

partituraMeas = np.empty([0, 1])
partituraTempo = np.empty([0, 1])
for i in range(1, len(mudancas)):
    num = int(mudancas[i][1])-int(mudancas[i-1][1])
    partituraMeas = np.append(partituraMeas, num*[int(mudancas[i-1][2])])
    partituraTempo = np.append(partituraTempo, num*[int(mudancas[i-1][3])])


print(partituraMeas)
beatReference = np.array([])
for mudanca in mudancas:
    num = int(mudanca[1])

    beatReference = np.append(beatReference, np.sum(partituraMeas[:num]))

count = 0
mudancasCount = 0
# Função para calcular o tempo entre cliques do teclado
def on_key_event(event):
    global last_time
    current_time = time.time()
    
    global count
    global durations
    global mudancasCount
    global beatReference
    global mudancas

    if last_time is not None:
        time_between_clicks = current_time - last_time
        durations = np.append(durations, time_between_clicks)
        count += 1
        if (count > beatReference[mudancasCount]):
            mudancasCount += 1
        print("\n\n\n")
        print(f"Tempo entre cliques: {time_between_clicks:.4f} segundos")
        print(f"Proxima mudanca em {beatReference[mudancasCount] - count} - {mudancas[mudancasCount, 0]}")
    
    # Atualiza o tempo da última tecla pressionada
    last_time = current_time

# Configura o listener para capturar qualquer tecla pressionada
keyboard.on_press(on_key_event)

# Mantém o programa em execução
keyboard.wait('esc')  # O programa vai parar ao pressionar 'esc'

np.savetxt('data.csv', durations, delimiter=',')