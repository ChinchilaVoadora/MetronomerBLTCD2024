import keyboard
import time

import numpy as np

import matplotlib.pyplot as plt

durations = np.genfromtxt('data.csv', delimiter=',')


mudancas = np.array([["Ijexa - 4/4 - 105", 0, 4, 105]])
mudancas = np.append(mudancas, [["Transiçao Ijexa - 6/8 - 210", 8, 6, 210]], axis=0)
mudancas = np.append(mudancas, [["Barravento - 6/8 - 210", 9, 6, 210]], axis=0)
mudancas = np.append(mudancas, [["Retomada barravento - 4/4 - 140", 14, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Samba - 4/4 - 140", 24, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["XL - 4/4 - 140", 32, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Salmonela - 4/4 - 140", 63, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Treansicion - 4/4 - 140", 82, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Noveoito - 9/8 - 280", 86, 9, 280]], axis=0)
mudancas = np.append(mudancas, [["Retomada - 4/4 - 140", 100, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Aquarela Chamada - 4/4 - 140", 112, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Aquarela Solo - 4/4 - 140", 138, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Bhangra desengatada - 3/4 - 140", 164, 3, 140]], axis=0)
mudancas = np.append(mudancas, [["Bhangra makonha - 4/4 - 187", 167, 4, 187]], axis=0)
mudancas = np.append(mudancas, [["Bhangra Solo - 4/4 - 187", 185, 4, 187]], axis=0)
mudancas = np.append(mudancas, [["UUUMMM DOIS - 4/4 - 187", 205, 4, 187]], axis=0)
mudancas = np.append(mudancas, [["Samba - 4/4 - 140", 218, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Tois - 4/4 - 140", 224, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Samba em 6 - 6/4 - 140", 261, 6, 140]], axis=0)
mudancas = np.append(mudancas, [["Brastemp - 4/4 - 140", 263, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Jongo - 4/4 - 140", 283, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Pare - 4/4 - 140", 298, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Flamenco Intro - 7/4 - 140", 305, 7, 140]], axis=0)
mudancas = np.append(mudancas, [["Flamenco REAL - 4/4 - 93", 306, 4, 93]], axis=0)
mudancas = np.append(mudancas, [["Flamenco CERNE - 12/8 - 93", 317, 12, 93]], axis=0)
mudancas = np.append(mudancas, [["Flamenco FINAL - 3/4 - 140", 339, 3, 140]], axis=0)
mudancas = np.append(mudancas, [["Samba - 4/4 - 140", 335, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["N sei - 4/4 - 140", 349, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Solo pinico - 4/4 - 140", 363, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Makulele - 4/4 - 140", 390, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Whiskas - 4/4 - 140", 402, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Whiskas LENTO - 4/4 - 93", 406, 4, 93]], axis=0)
mudancas = np.append(mudancas, [["SOLO DE SEXO - 4/4 - 196", 421, 4, 196]], axis=0)
mudancas = np.append(mudancas, [["BLACK HAHAHA - 4/4 - 196", 435, 4, 196]], axis=0)
mudancas = np.append(mudancas, [["Frevo - 4/4 - 196", 451, 4, 196]], axis=0)
mudancas = np.append(mudancas, [["Saksifufu - 4/4 - 140", 468, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Hunter - 4/4 - 140", 485, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Bilu intro - 3/4 - 140", 523, 3, 140]], axis=0)
mudancas = np.append(mudancas, [["Bilu - 4/4 - 140", 527, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Makumba - 5/4 - 140", 556, 5, 140]], axis=0)
mudancas = np.append(mudancas, [["Makumba - 4/4 - 140", 557, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Makumba - 5/4 - 140", 559, 5, 140]], axis=0)
mudancas = np.append(mudancas, [["Makumba - 4/4 - 140", 560, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Timpanos - 4/4 - 140", 570, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Caveça - 4/4 - 140", 586, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Dinossauro - 4/4 - 140", 622, 4, 140]], axis=0)
mudancas = np.append(mudancas, [["Pre final - 3/4 - 140", 639, 3, 140]], axis=0)
mudancas = np.append(mudancas, [["CABO - 4/4 - 140", 641, 4, 140]], axis=0)


partituraMeas = np.empty([0, 1])
partituraTempo = np.empty([0, 1])
for i in range(1, len(mudancas)):
    num = int(mudancas[i][1])-int(mudancas[i-1][1])
    partituraMeas = np.append(partituraMeas, num*[int(mudancas[i-1][2])])
    partituraTempo = np.append(partituraTempo, num*[int(mudancas[i-1][3])])



beatReference = np.array([])
for mudanca in mudancas:
    num = int(mudanca[1])

    beatReference = np.append(beatReference, np.sum(partituraMeas[:num]))
    

beats = 0
temposPerMeasure = np.array([])
for measure in partituraMeas:
    bpm = 60/(np.average(durations[beats:int(beats+measure)]))
    beats += int(measure)
    temposPerMeasure = np.append(temposPerMeasure, bpm)
    

average = 8
mediaMovel = temposPerMeasure[:average]
print(mediaMovel)
for i in range(len(temposPerMeasure)):
    if i > (average-1):
        sum = 0
        n = 0
        for j in range(average):
            if (np.abs(temposPerMeasure[i-j] - partituraTempo[i]) < partituraTempo[i]*0.2):
                sum += temposPerMeasure[i-j]*(average-j)
                n += (average-j)
        if(n != 0):
            sum = sum/n
            print(sum)
            mediaMovel = np.append(mediaMovel, [sum])
        else:
            mediaMovel = np.append(mediaMovel, temposPerMeasure[i])            

x = range(len(partituraMeas))  # 100 pontos entre 0 e 10
y = temposPerMeasure  # Aplicando a função seno aos valores de x

# Criar o gráfico usando matplotlib
#plt.plot(x, y)
plt.plot(x, partituraTempo)
plt.plot(x, mediaMovel)


# Adicionar título e rótulos aos eixos
plt.title('Gráfico da função Seno')
plt.xlabel('Compasso')
plt.ylabel('Andamento')

plt.ylim(50, 300)

for mudanca in mudancas:
    num = int(mudanca[1])
    plt.vlines(num, 0, 300, linestyle='--', linewidth=0.1, label="oi")
    plt.annotate(mudanca[0], [int(mudanca[1]), int(mudanca[3])], fontsize=5, rotation=60)

# Exibir o gráfico
plt.show()